BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "user" (
	"userID"	INTEGER NOT NULL,
	"username"	VARCHAR(40),
	"email"	VARCHAR(50),
	"password"	VARCHAR(50),
	"is_admin"	BOOLEAN,
	PRIMARY KEY("userID"),
	UNIQUE("email"),
	UNIQUE("username")
);
CREATE TABLE IF NOT EXISTS "category" (
	"categoryID"	INTEGER NOT NULL,
	"main_category"	VARCHAR(255) NOT NULL,
	"name"	VARCHAR(100) NOT NULL,
	"icon_path"	VARCHAR(255) NOT NULL,
	"endpoint_name"	VARCHAR(255) NOT NULL,
	PRIMARY KEY("categoryID"),
	UNIQUE("name")
);
CREATE TABLE IF NOT EXISTS "advertisement" (
	"advertisementID"	INTEGER NOT NULL,
	"userID"	INTEGER,
	"date"	DATETIME,
	"title"	VARCHAR(60) NOT NULL,
	"category"	VARCHAR(100) NOT NULL,
	"available"	BOOLEAN,
	"description"	TEXT(10000),
	"price"	INTEGER NOT NULL,
	"image_path"	TEXT(255) NOT NULL,
	PRIMARY KEY("advertisementID"),
	FOREIGN KEY("userID") REFERENCES "user"("userID")
);
CREATE TABLE IF NOT EXISTS "comment" (
	"commentID"	INTEGER NOT NULL,
	"userID"	INTEGER,
	"advertisementID"	INTEGER,
	"content"	VARCHAR(300) NOT NULL,
	"date"	DATETIME,
	PRIMARY KEY("commentID"),
	FOREIGN KEY("userID") REFERENCES "user"("userID"),
	FOREIGN KEY("advertisementID") REFERENCES "advertisement"("advertisementID")
);
INSERT INTO "user" ("userID","username","email","password","is_admin") VALUES (1,'admin','admin@admin.com','pbkdf2:sha256:600000$c9iGZuavI81wt7Ji$c2772fcebeda818ab82f93a6fb2d94b1c6a5863f491a7be286e38acb7607f5b9',1);
INSERT INTO "user" ("userID","username","email","password","is_admin") VALUES (2,'teszt','teszt@teszemveszem.hu','pbkdf2:sha256:600000$6W1PTA59CzQiTuzr$0fb106b343f8803799b2ffaf518017d7c4197d35c0836057f2da5f220ed3cdaa',0);
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (1,'hardver','Alaplap','bi-motherboard','alaplap');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (2,'hardver','Processzor','bi-cpu','processzor');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (3,'hardver','Memória','bi-memory','memoria');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (4,'hardver','Hűtés','bi-fan','hutes');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (5,'hardver','Ház, táp','bi-pc','haz_tap');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (6,'hardver','Játékvezérlő, szimulátor','bi-controller','jatekvezerlo_szimulator');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (7,'hardver','VR','bi-badge-vr','vr');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (8,'hardver','Billentyűzet, egér(pad)','bi-keyboard','billentyuzet_eger');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (9,'hardver','Egyéb hardverek','bi-pci-card','egyeb_hardverek');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (10,'hardver','Retró hardverek','bi-archive','retro_hardverek');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (11,'hardver','Videókártya','bi-gpu-card','videokartya');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (12,'hardver','Monitor','bi-display','monitor');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (13,'hardver','Merevlemez, SSD','bi-hdd','merevlemez_ssd');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (14,'hardver','Adathordozó','bi-sd-card','adathordozo');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (15,'hardver','Hálózati termékek','bi-router','halozati_termekek');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (16,'hardver','Nyomtató, szkenner','bi-printer','nyomtato_szkenner');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (17,'mobil','IPhone','bi-phone','iphone');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (18,'mobil','Samsung','bi-phone','samsung');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (19,'mobil','Sony','bi-phone','sony');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (20,'mobil','LG','bi-phone','lg');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (21,'mobil','Asus','bi-phone','asus');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (22,'mobil','Google','bi-phone','google');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (23,'mobil','Xiaomi, Redmi, Poco','bi-phone','xiaomi_redmi_poco');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (24,'mobil','Huawei','bi-phone','huawei');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (25,'mobil','Honor','bi-phone','honor');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (26,'mobil','Realme','bi-phone','realme');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (27,'mobil','OnePlus','bi-phone','oneplus');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (28,'mobil','Oppo','bi-phone','oppo');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (29,'mobil','Nokia','bi-phone','nokia');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (30,'mobil','Motorola','bi-phone','motorola');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (31,'mobil','Lenovo','bi-phone','lenovo');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (32,'notebook','MacBook','bi-laptop','macbook');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (33,'notebook','MacBook Air','bi-laptop','macbook_air');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (34,'notebook','MacBook Pro','bi-laptop','macbook_pro');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (35,'notebook','Subnotebook','bi-laptop','subnotebook');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (36,'notebook','Könnyű notebook','bi-laptop','konnyu_notebook');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (37,'notebook','Asztali notebook','bi-laptop','asztali_notebook');
INSERT INTO "category" ("categoryID","main_category","name","icon_path","endpoint_name") VALUES (38,'notebook','Nagyméretű notebook','bi-laptop','nagymeretu_notebook');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (1,2,'2024-04-16 09:33:08','Redmi 4X','Xiaomi, Redmi, Poco',1,'<h3>Xiaomi Redmi 4X</h3>
<p>&nbsp;- 3/32GB model<br>&nbsp;- k&eacute;pen l&aacute;that&oacute; t&ouml;r&ouml;tt kijelzővel (nem nagy előny, de m&eacute;g gy&aacute;ri kijelzője)<br>&nbsp;- nem t&uacute;l gyors, alapvető k&ouml;z&ouml;ss&eacute;gi-m&eacute;dia haszn&aacute;latra &eacute;s internetez&eacute;sre alkalmas, de mindennapos haszn&aacute;latra nem javaslom</p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111</em></p>',5000,'teszt_20240416124934_torott-telefon.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (2,2,'2024-04-16 09:40:40','Samsung Galaxy A52 5G','Samsung',1,'<h3>Samsung Galaxy A52 5G</h3>
<p>sima A52, nem "s"</p>
<p>&nbsp;- 4/128GB<br>&nbsp;- mindennapos haszn&aacute;latb&oacute;l &eacute;rkező telefon<br>&nbsp;- bal felső sark&aacute;n a keretből hi&aacute;nyzik egy darab &eacute;s a kijelző t&ouml;r&ouml;tt<br>&nbsp;- h&aacute;tlapr&oacute;l p&ouml;tty&ouml;kben lekopott a fest&eacute;k</p>
<p><em>Gy&aacute;ri t&ouml;ltőj&eacute;vel egy fekete kem&eacute;ny tokkal adom.</em></p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111<br></em></p>',40000,'teszt_20240416122944_A52_5G.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (3,2,'2024-04-16 10:17:30','Alza powerbank','Egyéb hardverek',1,'<h3>Alza Power powerbank</h3>
<p>&nbsp;- 30.000 mAh teljes kapacit&aacute;s<br>&nbsp;- keveset haszn&aacute;lt</p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111</em></p>',10000,'teszt_20240416121730_powerbank.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (4,2,'2024-04-16 10:19:35','HP monitor','Monitor',1,'<h3>HP irodai monitor - P223</h3>
<p>&nbsp;- VA paneles<br>&nbsp;- FullHD 21,5"<br>&nbsp;- &aacute;ltal&aacute;nos irodai haszn&aacute;latb&oacute;l, j&oacute; &aacute;llapotban</p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111</em></p>',10000,'teszt_20240416121935_monitor.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (5,2,'2024-04-16 10:24:36','HP irodai gép','Egyéb hardverek',1,'<h3>HP ProDesk 400 G5 SFF</h3>
<p>&nbsp;- &aacute;ltal&aacute;nos irodai haszn&aacute;latb&oacute;l, j&oacute; &aacute;llapotban<br>&nbsp;- Windows 11 kompatibilis</p>
<p>Specifik&aacute;ci&oacute;k:<br>&nbsp;- Intel i5-8500 (6 mag, 3 GHz)<br>&nbsp;- 8GB ram<br>&nbsp;- 500 GB Toshiba HDD</p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111</em></p>',50000,'teszt_20240416122436_pc.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (6,2,'2024-04-16 10:26:20','Irodai billentyűzet','Billentyűzet, egér(pad)',1,'<h3>HP KU-1156 irodai billentyűzet</h3>
<p>&nbsp;- magyar kioszt&aacute;s&uacute;<br>&nbsp;- &aacute;ltal&aacute;nos irodai haszn&aacute;latb&oacute;l, j&oacute; &aacute;llapot&uacute;, bej&aacute;ratott billentyűzet</p>
<p>El&eacute;rhetős&eacute;g: 06701111111</p>',2000,'teszt_20240416122849_billentyuzet.jpg');
INSERT INTO "advertisement" ("advertisementID","userID","date","title","category","available","description","price","image_path") VALUES (7,2,'2024-04-16 10:28:25','Egszerű PC egér','Billentyűzet, egér(pad)',1,'<h3>HP MOFYUO irodai eg&eacute;r</h3>
<p>&nbsp;- &aacute;ltal&aacute;nos irodai haszn&aacute;latb&oacute;l</p>
<p><em>El&eacute;rhetős&eacute;g: 06701111111</em></p>',500,'teszt_20240416122825_eger.jpg');
COMMIT;
